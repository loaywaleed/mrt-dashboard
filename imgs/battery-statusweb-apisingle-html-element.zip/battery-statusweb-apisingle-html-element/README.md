# Battery Status - Web API - Single HTML Element

A Pen created on CodePen.io. Original URL: [https://codepen.io/loay-waleed/pen/WNBNBar](https://codepen.io/loay-waleed/pen/WNBNBar).

